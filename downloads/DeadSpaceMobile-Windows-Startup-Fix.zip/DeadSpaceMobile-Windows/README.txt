DEAD SPACE MOBILE - WINDOWS STARTUP FIX

This build fixes the crash reported at startup in EA::core::GetAccelerometer.
The Windows compatibility bridge now exposes a stationary logical sensor,
allowing the original game's accelerometer object to be created.
It supplies neutral gravity, not physical motion or synthetic shake gestures.

UPDATE AN EXISTING INSTALLATION
Extract this ZIP and copy its files into the existing folder containing
Play Dead Space.cmd. Keep your game and userdata folders. No game assets
or saves are included in this update, and none need to be deleted.

NEW INSTALLATION
Extract the entire ZIP into a writable folder on Windows 10/11, then run
Play Dead Space.cmd. Select your matching Fixes or Reanimated v1.3 APK when asked:
https://github.com/RAFALAMAO/Dead-Space-Mobile-Fixes/releases
https://github.com/GINESTR0/DeadSpaceReanimated/releases/tag/v1.3
The required libDeadSpace.so SHA1 is:
64a3323cd3cc0c483a645b62af8508624163ba9b

Reanimated's original 32-bit library and assets are normalized to the same
layout, and its optional KTX HD pack is installed under game/texture_hd.
To add that pack to an existing Fixes install, supply the Reanimated APK
with Launch.ps1 -Apk. The -DisableHdTextures switch selects original textures.

The EXE already contains the translated game functions compiled for native
32-bit Windows. No compiler, WSL or Android emulator is needed to play.
The original libDeadSpace.so is still read for its data, tables and relocation
information. Its presence in a startup log does not mean Android code is run.

CONTROLLER SOURCE LIMITATION
This uses the older committed touchscreen/keyboard controller frontend.
The latest Linux RAR supplies a newer native-controller executable, but not
the source or translation hooks for that implementation. Its libds2controls.c
is only the button remapper. The latest Linux DS2 layout is not reproduced.

WASD or left stick: move. Right stick: camera drag. F1: mouse capture.
Escape/Options: pause/back. Cross/E/Enter: interact. Square/R: reload.
L2: aim. Aimed R2: fire. R1: plasma-saw swipe. Unaimed R2: stomp swipe.
Use the mouse for opening menus and difficulty selection.

Saves: userdata/var. Session logs: logs. Keep userdata when updating.
Default display: 1366x768. Desktop OpenGL 2.1 is required.
Windows motion hardware and later motion-controlled gameplay are unverified.
See RELEASE_AUDIT.txt, VERIFICATION.txt and BUILD_INFO.txt for coverage and limits.
