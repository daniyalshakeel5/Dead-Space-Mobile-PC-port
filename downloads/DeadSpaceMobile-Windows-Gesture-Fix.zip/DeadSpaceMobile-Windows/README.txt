DEAD SPACE MOBILE - WINDOWS GRAB GESTURES FIX

ENEMY GRABS
Cross/A: press repeatedly for tap prompts (one native tap per press).
Right stick: flick in the indicated swipe direction, then return to centre.
R1/right shoulder: contextual swipe response using the game's original
controller-compatible grapple routine. It only responds in a valid swipe phase.
Ordinary movement, aiming and combat mappings are suspended during the grab.
Mouse capture releases automatically during grabs and menus, showing the
cursor for physical clicks/drags. It resumes afterward only if requested.
F1 toggles capture intent; Escape or focus loss cancels it.
Original on-screen tap/swipe artwork remains unchanged.
Shake/motion-only campaign interactions are not remapped by this update.

AUDIO AND DISPLAY

The Windows audio submission loop now uses a high-resolution deadline timer,
accounting for its processing time instead of accumulating coarse sleeps.
The original mixer and submit threads get Windows audio-friendly priority.
Playback waits for two device periods of queued PCM before starting. The
original 48 kHz stereo mixer, decoders and native controller path are retained.
Low queues refill promptly after scheduling/loading stalls. The queue starts
at 4096 frames; underruns add bounded headroom up to 12288 frames (256 ms at
48 kHz), reduced after stable playback. Queued PCM is never dropped to resize.

Windows detects the display under the pointer and opens borderless fullscreen
at its desktop resolution, with DPI-aware rendering. F11 toggles windowed mode;
Launch.ps1 -Windowed starts in a window instead.

This build fixes the crash reported at startup in EA::core::GetAccelerometer.
The Windows compatibility bridge now exposes a stationary logical sensor,
allowing the original game's accelerometer object to be created.
It supplies neutral gravity, not physical motion or synthetic shake gestures.

UPDATE AN EXISTING INSTALLATION
Extract this ZIP and copy its files into the existing folder containing
Play Dead Space.cmd. Keep your game and userdata folders. No game assets
or saves are included in this update, and none need to be deleted.

NEW INSTALLATION
Extract the entire ZIP into a writable folder on Windows 10/11, then run
Play Dead Space.cmd. Select your matching Fixes or Reanimated v1.3 APK when asked:
https://github.com/RAFALAMAO/Dead-Space-Mobile-Fixes/releases
https://github.com/GINESTR0/DeadSpaceReanimated/releases/tag/v1.3
The required libDeadSpace.so SHA1 is:
64a3323cd3cc0c483a645b62af8508624163ba9b

Reanimated's original 32-bit library and assets are normalized to the same
layout, and its optional KTX HD pack is installed under game/texture_hd.
To add that pack to an existing Fixes install, supply the Reanimated APK
with Launch.ps1 -Apk. The -DisableHdTextures switch selects original textures.

The EXE already contains the translated game functions compiled for native
32-bit Windows. No compiler, WSL or Android emulator is needed to play.
The original libDeadSpace.so is still read for its data, tables and relocation
information. Its presence in a startup log does not mean Android code is run.

NATIVE CONTROLLER
Controller sticks and buttons call the original game's semantic events and
live menu-button callbacks. They do not synthesize SDL mouse/touch events,
raw touchscreen down/move/up, or Android keyboard codes. Grab responses use
native semantic tap/gesture events directly on the current player instead.
SDL normalizes recognized pads.
This implementation was reconstructed from the latest Linux executable and
its release notes because the underlying native-controller source was absent.

Left stick: move. L1: hold run. L3: quick turn outside aim.
Right stick: native look/aim. R3: locator.
L2: hold aim. R2: fire while aiming, native stomp otherwise.
R1: alternate fire while aiming, native melee/Plasma Saw otherwise.
Cross/A: interact or activate focused menu item. Circle/B: kinesis.
Square/X: reload. Triangle/Y: stasis while aiming.
D-pad left/right: previous/next weapon. D-pad up: Zero-G jump.
D-pad down: menu navigation only. Options/Start: pause. Share/Back: Rig.
Menu navigation: left stick or D-pad. Cross/A confirms, Circle/B goes back.
Cross/A also continues from a completed loading screen using native methods.
Aim/fire checks for an equipped weapon; unarmed movement/melee/stomp remain.
Disconnect/focus loss releases controller-owned input on the next game update.
Physical mouse, touchscreen and keyboard fallback remain separate.

Saves: userdata/var. Session logs: logs. Keep userdata when updating.
Default display: detected desktop resolution, fullscreen. OpenGL 2.1 is required.
Physical controller hardware and later motion-controlled gameplay are unverified.
See RELEASE_AUDIT.txt, VERIFICATION.txt and BUILD_INFO.txt for coverage and limits.
Audio logs include AUDIO_NATIVE, AUDIO_TIMER and AUDIO_CLOCK (including empty
queue writes) so remaining hardware-specific problems can be identified.
