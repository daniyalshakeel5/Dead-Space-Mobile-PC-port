DEAD SPACE MOBILE - NATIVE WINDOWS TEST BUILD

Built from the source at the Linux-with-controller-support release tag of
daniyalshakeel5/Dead-Space-Mobile-PC-port (commit b1fa1ca87922).

CONTROLLER SOURCE LIMITATION
The latest Linux RAR includes a newer native controller implementation as a
compiled Linux executable. Its source and translator hooks are absent from
the RAR and the repository. libds2controls.c is only its button remapper.
This Windows build uses the committed, older touchscreen/keyboard controller
frontend. It does not reproduce the Linux release's native DS2 controls,
unarmed combat changes, or D-pad Up Zero-G mapping.

SETUP
1. Extract the entire ZIP into a writable folder on your Windows PC.
2. Double-click Play Dead Space.cmd.
3. Select your original Dead Space Mobile Fixes APK when prompted.
   The upstream APK is available from:
   https://github.com/RAFALAMAO/Dead-Space-Mobile-Fixes/releases
4. Use the mouse for difficulty selection and menus.

Requires Windows 10/11 on an x86-compatible PC with desktop OpenGL 2.1.
The included executable is native 32-bit Windows and runs on 64-bit Windows.
No WSL, compiler, Android runtime or administrator installation is required
to play. The original game library and assets are extracted from your APK
on first launch. They are not included in this ZIP.

The matching libDeadSpace.so SHA1 is:
64a3323cd3cc0c483a645b62af8508624163ba9b
The Xperia APK with libEAMGameDeadSpace.so is incompatible. This launcher
accepts the Fixes APK layout; it does not install a Reanimated APK.

COMMITTED FRONTEND CONTROLS
WASD or left stick: movement. Right stick: camera drag.
F1: toggle captured mouse look. Escape/Options: pause/back.
Cross/E/Enter: interact. Square/R: reload. Triangle/F: original Xperia action.
L2: aim. R2 while aiming: fire. R1: upper-left plasma-saw swipe.
R2 without aiming: upper-left stomp swipe. Share: original Select/Rig key.
These are the older source frontend's controls, not the latest Linux layout.

SAVES AND LOGS
Saves: userdata/var beside the executable, separate from immutable APK assets.
Logs: logs beside the executable. Keep userdata when updating this package.
The launcher requests 1366x768, the original game's SDL audio output,
resolution-scaled interaction thresholds, and the 1200-unit far-plane fix.
Windows motion sensor input and physical gamepad behavior are unverified.

See BUILD_INFO.txt for source and toolchain provenance. Tests under Wine
are useful smoke tests but do not establish behavior on physical Windows
hardware, long gameplay sessions, or campaign completion.
